Bayesian Model Averaging in Python


